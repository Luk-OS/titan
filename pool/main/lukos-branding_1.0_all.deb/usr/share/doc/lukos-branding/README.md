Paquete que aplica branding completo de Luk-OS (Kronos) 1.0 Alpha.
Crea backups en /var/backups/lukos-branding-branding-backup/.
Los cambios se revierten automáticamente al desinstalar.
NOTA: La modificación del hostname ha sido deshabilitada. También se configuró Neofetch y Fastfetch para usar el logo de imagen.
